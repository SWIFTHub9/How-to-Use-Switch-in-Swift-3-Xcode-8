//
//  ViewController.swift
//  How to use Switch
//
//  Created by Abhishek Verma on 23/06/17.
//  Copyright © 2017 Abhishek Verma. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Switch: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func SwitchValueChange(_ sender: Any) {
        if Switch.isOn {
            let alert = UIAlertController(title: "Switch Is ON", message: nil, preferredStyle: .alert)
            let ok = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alert.addAction(ok)
            self.present(alert, animated: true, completion: nil)
        }
        else
        {
            let alertoff = UIAlertController(title: "Switch is Off", message: nil, preferredStyle: .alert)
            let ok = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alertoff.addAction(ok)
            self.present(alertoff, animated: true, completion: nil)
        }
    }

}

